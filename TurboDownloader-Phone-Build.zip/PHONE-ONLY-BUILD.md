# Build Turbo Downloader APK using only an Android phone

This project includes `.github/workflows/build.yml` so GitHub's hosted runner can compile the APK. No Android SDK or PC is required on your phone.

## Steps
1. Create/sign in to a GitHub account in your phone browser.
2. Install Termux from the official F-Droid page: https://f-droid.org/packages/com.termux/ (avoid unofficial APK mirrors).
3. Download this ZIP to your phone and extract it using your file manager.
4. In Termux, install Git:
   `pkg update && pkg install git`
5. Move into the extracted project directory. The exact path depends on where your file manager extracted it. You may first run:
   `termux-setup-storage`
   then `cd ~/storage/downloads/TurboDownloader`
6. Initialize and push the project to a new empty GitHub repository (replace USER and REPO):
   `git init -b main`
   `git add .`
   `git commit -m "Add Turbo Downloader Android project"`
   `git remote add origin https://github.com/USER/REPO.git`
   `git push -u origin main`
7. If Git asks for a password, use a GitHub Personal Access Token with permission to write to that repository. Do not send the token to anyone or paste it into ChatGPT.
8. In GitHub, open the repository → Actions → **Build Turbo Downloader APK** → **Run workflow**.
9. Wait for the workflow to finish successfully. Open the completed run, find **Artifacts**, and download `TurboDownloader-debug-apk`.
10. Extract the artifact ZIP. Tap `app-debug.apk` to install. If Android asks, allow your browser/file manager to install unknown apps.

## Notes
- GitHub Actions runs the build on GitHub's servers. Your Android phone is only used to upload source and download the resulting APK.
- Keep the repository private if you prefer not to publish your source.
- This is a debug APK, suitable for personal testing. It is not a Play Store release.
- The APK has not yet been built or tested on a POCO M2 Pro. Test basic browsing and public direct downloads before relying on it.
